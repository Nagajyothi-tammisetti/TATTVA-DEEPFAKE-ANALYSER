"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { FileUpload } from "@/components/file-upload"
import { AnalysisResult, type AnalysisResult as AnalysisResultType } from "@/components/analysis-result"
import { Button } from "@/components/ui/button"
import { Loader2, AudioLines } from "lucide-react"

export default function AudioDetectionPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<AnalysisResultType | null>(null)
  const [progress, setProgress] = useState(0)

  const handleAnalyze = async () => {
    if (!selectedFile) return

    setAnalyzing(true)
    setResult(null)
    setProgress(0)

    console.log("[v0] Starting audio analysis for:", selectedFile.name)

    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + 9
      })
    }, 330)

    await new Promise((resolve) => setTimeout(resolve, 3500))
    setProgress(100)
    clearInterval(progressInterval)

    const fileSize = (selectedFile.size / 1024 / 1024).toFixed(2)
    const estimatedDuration = Math.floor(Math.random() * 20) + 5
    const sampleRate = selectedFile.name.toLowerCase().includes("wav") ? "48 kHz" : "44.1 kHz"

    const isDeepfake = Math.random() > 0.6
    const baseConfidence = isDeepfake ? 70 + Math.random() * 25 : 76 + Math.random() * 19

    const mockResult: AnalysisResultType = {
      isDeepfake,
      confidence: Math.round(baseConfidence),
      processingTime: 3.5,
      details: [
        { label: "Model Used", value: "Spectrogram CNN + MFCC" },
        { label: "Processing Time", value: "3.5 seconds" },
        { label: "Sample Rate", value: sampleRate },
        { label: "Duration", value: `${estimatedDuration} seconds` },
        { label: "File Size", value: `${fileSize} MB` },
        { label: "Voice Quality", value: isDeepfake ? "Synthetic markers detected" : "Natural characteristics" },
        { label: "Frequency Analysis", value: isDeepfake ? "Abnormal patterns" : "Normal distribution" },
      ],
    }

    console.log("[v0] Audio analysis complete:", mockResult)
    setResult(mockResult)
    setAnalyzing(false)
  }

  const handleClearFile = () => {
    setSelectedFile(null)
    setResult(null)
    setProgress(0)
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-chart-3/5 via-background to-chart-3/10" />
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url('/abstract-audio-waveform-sound-spectrum-pattern.jpg')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-background/85 backdrop-blur-sm" />
      </div>

      <Navigation />

      <main className="container mx-auto px-4 py-8 relative z-10">
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-12 w-12 rounded-lg bg-chart-3/10 flex items-center justify-center animate-pulse-slow">
              <AudioLines className="h-6 w-6 text-chart-3" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Audio Detection</h1>
              <p className="text-muted-foreground">Identify synthetic or cloned voices using spectrogram analysis</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6 animate-slide-up">
            <div>
              <h2 className="text-xl font-semibold mb-4">Upload Audio</h2>
              <FileUpload
                accept={{
                  "audio/*": [".mp3", ".wav", ".m4a", ".ogg"],
                }}
                onFileSelect={setSelectedFile}
                selectedFile={selectedFile}
                onClearFile={handleClearFile}
                maxSize={20971520}
              />
            </div>

            {selectedFile && !analyzing && !result && (
              <Button onClick={handleAnalyze} className="w-full transition-all hover:scale-105" size="lg">
                Analyze Audio
              </Button>
            )}

            {analyzing && (
              <div className="space-y-4 p-8 bg-card/50 backdrop-blur-sm rounded-lg border border-border animate-fade-in">
                <div className="flex items-center justify-center gap-3">
                  <Loader2 className="h-5 w-5 animate-spin text-chart-3" />
                  <span className="text-sm font-medium">Analyzing audio waveform...</span>
                </div>
                <div className="space-y-2">
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-chart-3 transition-all duration-300 ease-out"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground text-center">{progress}% complete</p>
                </div>
              </div>
            )}
          </div>

          <div className="animate-slide-up" style={{ animationDelay: "0.1s" }}>
            {result && selectedFile && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Results</h2>
                <AnalysisResult result={result} fileName={selectedFile.name} />
                <Button
                  onClick={handleClearFile}
                  variant="outline"
                  className="w-full mt-6 bg-transparent hover:bg-secondary transition-all"
                >
                  Analyze Another Audio
                </Button>
              </div>
            )}

            {!result && !analyzing && (
              <div className="p-8 bg-card/50 backdrop-blur-sm rounded-lg border border-border">
                <h2 className="text-xl font-semibold mb-4">About Audio Detection</h2>
                <div className="space-y-4 text-sm text-muted-foreground">
                  <p>Our spectrogram-based audio detection analyzes:</p>
                  <ul className="list-disc list-inside space-y-2 ml-2">
                    <li>Mel-frequency cepstral coefficients (MFCCs)</li>
                    <li>Spectrogram pattern anomalies</li>
                    <li>Voice quality and naturalness</li>
                    <li>Prosody and intonation patterns</li>
                    <li>Frequency domain artifacts</li>
                  </ul>
                  <p className="pt-2">
                    Supported formats: MP3, WAV, M4A, OGG
                    <br />
                    Maximum file size: 20MB
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
