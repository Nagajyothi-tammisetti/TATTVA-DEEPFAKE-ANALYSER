"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { FileUpload } from "@/components/file-upload"
import { AnalysisResult, type AnalysisResult as AnalysisResultType } from "@/components/analysis-result"
import { Button } from "@/components/ui/button"
import { Loader2, ImageIcon } from "lucide-react"

export default function ImageDetectionPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<AnalysisResultType | null>(null)
  const [progress, setProgress] = useState(0)

  const handleAnalyze = async () => {
    if (!selectedFile) return

    setAnalyzing(true)
    setResult(null)
    setProgress(0)

    console.log("[v0] Starting image analysis for:", selectedFile.name)

    // Simulate progressive analysis with progress updates
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + 10
      })
    }, 250)

    // Simulate realistic processing time
    await new Promise((resolve) => setTimeout(resolve, 2500))
    setProgress(100)
    clearInterval(progressInterval)

    const imageUrl = URL.createObjectURL(selectedFile)
    const img = new Image()
    img.src = imageUrl

    await new Promise((resolve) => {
      img.onload = resolve
    })

    const resolution = `${img.width}x${img.height}`
    const fileSize = (selectedFile.size / 1024 / 1024).toFixed(2)

    // Simulate detection with weighted randomness
    const isDeepfake = Math.random() > 0.65
    const baseConfidence = isDeepfake ? 75 + Math.random() * 20 : 80 + Math.random() * 15

    const mockResult: AnalysisResultType = {
      isDeepfake,
      confidence: Math.round(baseConfidence),
      processingTime: 2.5,
      details: [
        { label: "Model Used", value: "CNN ResNet-50" },
        { label: "Processing Time", value: "2.5 seconds" },
        { label: "Image Resolution", value: resolution },
        { label: "File Size", value: `${fileSize} MB` },
        { label: "Face Detection", value: isDeepfake ? "Anomalies detected" : "Natural features" },
        { label: "Frequency Analysis", value: isDeepfake ? "Suspicious patterns" : "Normal distribution" },
      ],
    }

    console.log("[v0] Analysis complete:", mockResult)
    setResult(mockResult)
    setAnalyzing(false)
    URL.revokeObjectURL(imageUrl)
  }

  const handleClearFile = () => {
    setSelectedFile(null)
    setResult(null)
    setProgress(0)
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-primary/10" />
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url('/abstract-image-analysis-digital-face-recognition-p.jpg')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-background/85 backdrop-blur-sm" />
      </div>

      <Navigation />

      <main className="container mx-auto px-4 py-8 relative z-10">
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center animate-pulse-slow">
              <ImageIcon className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Image Detection</h1>
              <p className="text-muted-foreground">Analyze images for AI-generated or manipulated content</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6 animate-slide-up">
            <div>
              <h2 className="text-xl font-semibold mb-4">Upload Image</h2>
              <FileUpload
                accept={{
                  "image/*": [".jpg", ".jpeg", ".png", ".webp"],
                }}
                onFileSelect={setSelectedFile}
                selectedFile={selectedFile}
                onClearFile={handleClearFile}
                maxSize={10485760}
              />
            </div>

            {selectedFile && !analyzing && !result && (
              <Button onClick={handleAnalyze} className="w-full transition-all hover:scale-105" size="lg">
                Analyze Image
              </Button>
            )}

            {analyzing && (
              <div className="space-y-4 p-8 bg-card/50 backdrop-blur-sm rounded-lg border border-border animate-fade-in">
                <div className="flex items-center justify-center gap-3">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  <span className="text-sm font-medium">Analyzing image...</span>
                </div>
                <div className="space-y-2">
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary transition-all duration-300 ease-out"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground text-center">{progress}% complete</p>
                </div>
              </div>
            )}
          </div>

          <div className="animate-slide-up" style={{ animationDelay: "0.1s" }}>
            {result && selectedFile && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Results</h2>
                <AnalysisResult result={result} fileName={selectedFile.name} />
                <Button
                  onClick={handleClearFile}
                  variant="outline"
                  className="w-full mt-6 bg-transparent hover:bg-secondary transition-all"
                >
                  Analyze Another Image
                </Button>
              </div>
            )}

            {!result && !analyzing && (
              <div className="p-8 bg-card/50 backdrop-blur-sm rounded-lg border border-border">
                <h2 className="text-xl font-semibold mb-4">About Image Detection</h2>
                <div className="space-y-4 text-sm text-muted-foreground">
                  <p>Our CNN-based image detection analyzes:</p>
                  <ul className="list-disc list-inside space-y-2 ml-2">
                    <li>Facial feature inconsistencies</li>
                    <li>Lighting and shadow anomalies</li>
                    <li>Edge artifacts and blending patterns</li>
                    <li>Frequency domain analysis</li>
                    <li>Compression artifacts</li>
                  </ul>
                  <p className="pt-2">
                    Supported formats: JPG, PNG, WEBP
                    <br />
                    Maximum file size: 10MB
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
