"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { FileUpload } from "@/components/file-upload"
import { AnalysisResult, type AnalysisResult as AnalysisResultType } from "@/components/analysis-result"
import { Button } from "@/components/ui/button"
import { Loader2, VideoIcon } from "lucide-react"

export default function VideoDetectionPage() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState<AnalysisResultType | null>(null)
  const [progress, setProgress] = useState(0)

  const handleAnalyze = async () => {
    if (!selectedFile) return

    setAnalyzing(true)
    setResult(null)
    setProgress(0)

    console.log("[v0] Starting video analysis for:", selectedFile.name)

    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + 8
      })
    }, 400)

    await new Promise((resolve) => setTimeout(resolve, 4500))
    setProgress(100)
    clearInterval(progressInterval)

    const fileSize = (selectedFile.size / 1024 / 1024).toFixed(2)
    const estimatedFrames = Math.floor(Math.random() * 200) + 100
    const estimatedDuration = (estimatedFrames / 30).toFixed(1)

    const isDeepfake = Math.random() > 0.55
    const baseConfidence = isDeepfake ? 72 + Math.random() * 23 : 78 + Math.random() * 17

    const mockResult: AnalysisResultType = {
      isDeepfake,
      confidence: Math.round(baseConfidence),
      processingTime: 4.5,
      details: [
        { label: "Model Used", value: "CNN-LSTM" },
        { label: "Processing Time", value: "4.5 seconds" },
        { label: "Frames Analyzed", value: `${estimatedFrames} frames` },
        { label: "Duration", value: `${estimatedDuration} seconds` },
        { label: "File Size", value: `${fileSize} MB` },
        { label: "Temporal Coherence", value: isDeepfake ? "Inconsistencies found" : "Consistent patterns" },
        { label: "Face Tracking", value: isDeepfake ? "Anomalous movements" : "Natural motion" },
      ],
    }

    console.log("[v0] Video analysis complete:", mockResult)
    setResult(mockResult)
    setAnalyzing(false)
  }

  const handleClearFile = () => {
    setSelectedFile(null)
    setResult(null)
    setProgress(0)
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-chart-2/5 via-background to-chart-2/10" />
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url('/abstract-video-frames-motion-detection-pattern.jpg')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-background/85 backdrop-blur-sm" />
      </div>

      <Navigation />

      <main className="container mx-auto px-4 py-8 relative z-10">
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-12 w-12 rounded-lg bg-chart-2/10 flex items-center justify-center animate-pulse-slow">
              <VideoIcon className="h-6 w-6 text-chart-2" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Video Detection</h1>
              <p className="text-muted-foreground">Detect deepfake videos with frame-by-frame analysis</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6 animate-slide-up">
            <div>
              <h2 className="text-xl font-semibold mb-4">Upload Video</h2>
              <FileUpload
                accept={{
                  "video/*": [".mp4", ".mov", ".avi", ".webm"],
                }}
                onFileSelect={setSelectedFile}
                selectedFile={selectedFile}
                onClearFile={handleClearFile}
                maxSize={52428800}
              />
            </div>

            {selectedFile && !analyzing && !result && (
              <Button onClick={handleAnalyze} className="w-full transition-all hover:scale-105" size="lg">
                Analyze Video
              </Button>
            )}

            {analyzing && (
              <div className="space-y-4 p-8 bg-card/50 backdrop-blur-sm rounded-lg border border-border animate-fade-in">
                <div className="flex items-center justify-center gap-3">
                  <Loader2 className="h-5 w-5 animate-spin text-chart-2" />
                  <span className="text-sm font-medium">Analyzing video frames...</span>
                </div>
                <div className="space-y-2">
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-chart-2 transition-all duration-300 ease-out"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground text-center">{progress}% complete</p>
                </div>
              </div>
            )}
          </div>

          <div className="animate-slide-up" style={{ animationDelay: "0.1s" }}>
            {result && selectedFile && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Results</h2>
                <AnalysisResult result={result} fileName={selectedFile.name} />
                <Button
                  onClick={handleClearFile}
                  variant="outline"
                  className="w-full mt-6 bg-transparent hover:bg-secondary transition-all"
                >
                  Analyze Another Video
                </Button>
              </div>
            )}

            {!result && !analyzing && (
              <div className="p-8 bg-card/50 backdrop-blur-sm rounded-lg border border-border">
                <h2 className="text-xl font-semibold mb-4">About Video Detection</h2>
                <div className="space-y-4 text-sm text-muted-foreground">
                  <p>Our CNN-LSTM video detection analyzes:</p>
                  <ul className="list-disc list-inside space-y-2 ml-2">
                    <li>Frame-by-frame facial inconsistencies</li>
                    <li>Temporal coherence patterns</li>
                    <li>Motion and expression anomalies</li>
                    <li>Blinking patterns and micro-expressions</li>
                    <li>Audio-visual synchronization</li>
                  </ul>
                  <p className="pt-2">
                    Supported formats: MP4, MOV, AVI, WEBM
                    <br />
                    Maximum file size: 50MB
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
